import re
from collections import Counter
import os
from pprint import pprint
from pymystem3 import Mystem

m = Mystem()

def load_stop_words(stop_filename):
	''' загрузить список стоп-слов из файла, одно слово на строке '''
	with open(stop_filename, encoding = 'utf-8') as f:
		stopwords = [w.strip() for w in f.readlines() if w.strip()]
	return set(stopwords)


def preprocessing(raw_text):
    clean_text = re.sub('\W+', ' ', raw_text) # \W = [^a-zA-Z0-9_]
    return clean_text

def lemmatize(input):
    return [lemma.strip() for lemma in m.lemmatize(preprocessing(input.lower())) if lemma.strip()]

#text = "с виду воду, которая бьёт  рядом с французским городом Авен"
#m.lemmatize(text)

#r_text = "Он еле дождался, пока я доковыряюсь ключом в замке и, не снимая сапожек, прямиком пошёл в свою спальню."
#print(preprocessing(text))
#print(lemmatize(text))

def remove_stop_words(lemmas, stopwords):
    return ' '.join([word for word in lemmas if word not in stopwords])

#stop_words_filename = 'D:/GooDrive/0_2018_Edu_CL2/0_2018_Edu_HSE_Bak_CL2/WSD/WSD_Classifier/stoplist_russian.txt' 	# одно слово на строке
stop_words = load_stop_words('stoplist.txt')
raw_texts = ['Он', 'еле', 'дождался', 'пока', 'я', 'доковыряюсь', 'ключом', 'в', 'замке', 'и', 'не', 'снимая']
print(remove_stop_words(raw_texts, stop_words))

# библиотека для поддержки различных кодировок при чтении/записи файлов
# вообще, все import лучше хранить в начале файла, но в IPython'е это не всегда удобно
import codecs

def load_files(filename):
    # список, где будут накапливаться результаты
    results = []
    
    # открываем файл как переменную inp_file.
    # Важно помнить, что в этой переменной хранится не сам текстовый файл, а своего рода указатель на него.
    # Файл еще предстоит прочитать.
    # Конструкция with следит за тем, чтобы переменная, которая после as, существовала только внутри блока.
    # Благодаря этому файл закроется сразу же после использования
    with(codecs.open(filename, encoding = 'utf-8')) as inp_file:
        # читаем первую строку "в никуда" (не сохраняем результат).
        # Первая строка у нас — это названия колонок, они нам не нужны
        inp_file.readline()
        # Для каждой строки в файле
        for line in inp_file:
            # откусываем концы строк
            line = line.strip('\r\n')
            # строка.count(подстрока) возвращает количество вхождений подстроки в строку
            if line.count('\t') != 1:
            # специальное ключевое слово для перехода к следующей итерации цикла
                continue
            # делим строку по табуляции и складываем в каждую из двух переменных очередное значение
            sence, context = line.split('\t')
            # добавляем кортеж (sence, context) в общий список результатов
            cx = lemmatize(context)
            cx = remove_stop_words(cx, stop_words)
            results.append((int(sence), cx))
    # возвращаем результаты в виде списка кортежей (sence, context)
    return results

# указываем абсолютный или относительный путь
data = load_files('glass_Atnagulova.txt')

# напечатаем первые 10 элементов нашего корпуса
for item in data[:10]:
    print (item[0], item[1])
    
with codecs.open('lemmatized_data.txt', mode='w', encoding='utf-8') as wr:
    wr.write('sense\tcontext(lemmatized)\r\n')
    for item in data:
        wr.write(str(item[0]) + '\t' + item[1] + "\r\n")

# математика
import numpy

# разные классификаторы
from sklearn.naive_bayes import MultinomialNB
from sklearn import tree
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import LinearSVC

# векторизация
from sklearn.feature_extraction.text import CountVectorizer, TfidfVectorizer

# деление корпуса train/test
from sklearn.model_selection import cross_val_score
from sklearn.model_selection import train_test_split

# Pipeline
from sklearn.pipeline import Pipeline

x_context = [item[1] for item in data]
y_labels = [item[0] for item in data]
print(x_context[:5])
print(y_labels[1])

def tokenize(input):
    return input.split(' ')

classifiers = [('SVM', LinearSVC), ('Bayes', MultinomialNB)]
vectorizers = [('Counts', CountVectorizer), ('TfIdf', TfidfVectorizer)]

def score_classifier(clf, metric='f1'):
    scores = cross_val_score(pipeline, numpy.asarray(x_context), numpy.asarray(y_labels), cv=5, scoring=metric)
    score = sum(scores) / len(scores)
    
    return score

clf = MultinomialNB()
pipeline = Pipeline(
[
  ('vectorizer',  TfidfVectorizer(tokenizer=tokenize)),
  ('classifier',  clf)
])

pipeline.fit(numpy.asarray(x_context), numpy.asarray(y_labels))
pipeline.predict(x_context)

pipeline.predict([u'из ключа вода'])

print (score_classifier(pipeline))
print (score_classifier(pipeline, 'precision'))
print (score_classifier(pipeline, 'recall'))

for clf in classifiers:
    for vctr in vectorizers:
        pipeline = Pipeline([
    ('vectorizer', vctr[1]()),
    ('classifier', clf[1]()) ])
        print (clf[0], vctr[0], score_classifier(pipeline))

scores = cross_val_score(pipeline, numpy.asarray(x_context), numpy.asarray(y_labels), cv=5, scoring='f1')
score = sum(scores) / len(scores)

print (score)
print (scores)

def score_classifier(clf, metric='f1'):
    scores = cross_val_score(pipeline, numpy.asarray(x_tweets), numpy.asarray(y_labels), cv=5, scoring=metric)
    score = sum(scores) / len(scores)
    
    return score

scores = cross_val_score(pipeline, numpy.asarray(x_context), numpy.asarray(y_labels), cv=5, scoring='f1')
score = sum(scores) / len(scores)

print (score)
print (scores)

#import sklearn

from nltk.corpus import stopwords
from sklearn.cross_validation import train_test_split
from sklearn.cross_validation import KFold
from sklearn.naive_bayes import MultinomialNB
from sklearn import tree
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import LinearSVC

from sklearn.metrics import precision_recall_curve
from sklearn.metrics import average_precision_score
from sklearn.model_selection import train_test_split

import numpy as np

from sklearn.feature_extraction.text import BinaryVectorizer, CountVectorizer, TfidfVectorizer

import os, sys, codecs

texts = [item[1] for item in data]
for i in range(10):
    print (texts[i])
    
len(texts)

print (3974 *16344 * 4)

vectorizer = TfidfVectorizer()

texts = [item[1] for item in data]
vectorized = vectorizer.fit_transform(texts)
vectorized

print (vectorized[0], vectorized[0].shape)

clf = RandomForestClassifier(n_estimators=250)
y_labels = [item[0] for item in data]
clf.fit(vectorized.toarray(), y_labels)

#clf.predict(vectorizer.fit([u'все было ужасно']))
clf.predict(vectorized[0].toarray())
print (y_labels[0])

y_labels = [item[0] for item in data]
X_train, X_test, y_train, y_test = train_test_split(vectorized, y_labels, test_size=0.1, random_state=42)
len(y_labels)
X_train.shape
y_train.shape
X_test[0].getnnz()

names = vectorizer.get_feature_names()
items = clf.predict(X_test.toarray())
right = 0
for i in range(len(items)):
    if items[i] == y_test[i]:
        right += 1
        
print ('Total: %d\nRight: %d\nScore: %.3f' % (len(items), right, float(right) / len(items)))

words = {}
for i in range(len(clf.feature_importances_)):
    words[names[i]] = clf.feature_importances_[i]
    
for item in sorted(words, key = lambda word: words[word], reverse=True):
    print (item, words[item])


#print data[10][0], data[10][1]
#items = clf.predict(vectorized[10])
#print items[0]
#print X_test
items = clf.predict(X_test.toarray())
right = 0
for i in range(len(items)):
    if items[i] == y_test[i]:
        right += 1
    #print items[i], y_test[i]
names = vectorizer.get_feature_names()
words = {}
print ('Total: %d\nRight: %d\nScore: %.3f' % (len(items), right, float(right) / len(items)))
for i in range(len(clf.feature_importances_)):
    words[names[i]] = clf.feature_importances_[i]
    
for item in sorted(words, key = lambda word: words[word], reverse=True):
    print (item, words[item])

names = vectorizer.get_feature_names()
len(names)

print (len(data))
kf = KFold(3300, n_folds=10)
for train, test in kf:
    #print train, test
    X_train, X_test, y_train, y_test = vectorized[train], vectorized[test], y_labels[train], y_labels[test]
